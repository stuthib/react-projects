import React from 'react';
import Ingredients from './Ingredients';
import IngredientList from './IngredientList';

class Submit extends React.Component {

  constructor(props) {
    super(props);
    this.submitRecipeClick = this.submitRecipeClick.bind(this);
    this.handleAddIngredientBtnClick = this.handleAddIngredientBtnClick.bind(this);

    this.state = {
      recipies : [],
      newRecipie : {
        name : 'New Recipie',
        description : 'Description',
        ingredients : []
      }
    };
  }

  submitRecipeClick() {

    console.log("First log", this.state.recipies);
    //console.log('Submit Recipie');
		//console.log(this.name.value, this.description.value);
		let newRecipie = this.state.newRecipie;

		newRecipie.name = this.name.value;
		newRecipie.description = this.description.value;
		newRecipie.image = this.state.uploadedFileCloudinaryUrl;
		this.setState((prevState) => {
      return {
        newRecipie : newRecipie,
      }
    });
    this.addRecipies();
  }

   addRecipies() {
    this.setState((prevState) => {
      console.log(prevState);
      let all = prevState.recipies;
      all.push(prevState.newRecipie);
      return {
        recipies: all

      }
    });
  }

  handleAddIngredientBtnClick(quantity, ingredient) {
    //console.log("Add Ingredients in Submit js", quantity, ingredient);
		let newRecipie = this.state.newRecipie;
		newRecipie.ingredients.push({quantity: quantity, ingredient: ingredient});
		this.setState({newRecipie: newRecipie});
		//console.log(newRecipie);
  }

  render() {
    return(
      <div className="row">
        <div className="col-xs-12 col-sm-12">
          <form>
            <div className="form-group">
              <label htmlFor="name">Name</label>
              <input type="text"
                     className="form-control"
                     id="name"
                     placeholder="Enter the name of the recipie"
                     ref={(name) => {this.name = name;}} />
            </div>
            <div className="form-group">
              <label htmlFor="description">Description</label>
              <textarea className="form-control"
                        id="description"
                        placeholder="Enter a brief description of the recipie"
                        ref={(description) => {this.description = description;}} />
            </div>


            <Ingredients onAddIngredientBtnClick={(quantity, ingredient) => this.handleAddIngredientBtnClick(quantity, ingredient)} />
            <div className="form-group">
              <IngredientList ingredientList={this.state.newRecipie.ingredients} />
            </div>
            <button type="button" onClick={this.submitRecipeClick} className="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    );
  }
}

export default Submit;
